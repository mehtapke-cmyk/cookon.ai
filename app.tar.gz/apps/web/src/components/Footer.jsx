import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Facebook, Twitter, Linkedin } from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { icon: Instagram, href: 'https://instagram.com' },
    { icon: Facebook, href: 'https://facebook.com' },
    { icon: Twitter, href: 'https://x.com' },
    { icon: Linkedin, href: 'https://linkedin.com' }
  ];

  const quickLinks = [
    { title: 'What we offer', href: '#features' },
    { title: 'Our work', href: '#portfolio' },
    { title: 'About us', href: '#about' },
    { title: 'Contact', href: '#contact' }
  ];

  const handleScroll = (e, id) => {
    e.preventDefault();
    document.querySelector(id).scrollIntoView({
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-[#000] text-white py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div>
            <span className="text-2xl font-light">Evolved</span>
            <p className="mt-4 text-gray-400 leading-relaxed">
              Transforming spaces into extraordinary experiences through innovative design.
            </p>
          </div>

          <div>
            {/* <span className="text-base font-light mb-4 block">Navigation</span> */} {/* Removed Navigation text */}
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.title}>
                  <a 
                    href={link.href} 
                    onClick={(e) => handleScroll(e, link.href)}
                    className="text-gray-400 hover:text-white transition-colors duration-300"
                  >
                    {link.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <span className="text-base font-light mb-4 block">Follow us</span>
            <div className="flex gap-4">
              {socialLinks.map((social, index) => (
                <motion.a 
                  key={index} 
                  href={social.href} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  whileHover={{ scale: 1.1 }} 
                  whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>© 2025 Evolved. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;