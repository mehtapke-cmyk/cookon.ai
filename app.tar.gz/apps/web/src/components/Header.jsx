import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const navItems = [{
    label: 'POURQUOI COOK ON AI',
    id: 'pourquoi-cook-on-ai'
  }, {
    label: 'À PROPOS',
    id: 'a-propos'
  }, {
    label: 'CONTACT',
    id: 'contact'
  }];
  const scrollToSection = (e, sectionId) => {
    e.preventDefault();
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 80,
        // Adjust for header height
        behavior: 'smooth'
      });
    }
    setIsMobileMenuOpen(false);
  };
  const mobileMenuVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  const mobileLinkVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0
    }
  };
  return <>
      <motion.header initial={{
      y: -100
    }} animate={{
      y: 0
    }} transition={{
      duration: 0.6,
      ease: "easeOut"
    }} className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            <motion.a href="#" onClick={e => {
            e.preventDefault();
            window.scrollTo({
              top: 0,
              behavior: 'smooth'
            });
          }} whileHover={{
            scale: 1.05
          }} className={`text-2xl font-display font-medium tracking-tight cursor-pointer ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
              Cookon.ai
            </motion.a>

            <nav className="hidden md:flex items-center gap-8">
              {navItems.map((item, index) => <motion.a key={item.id} href={`#${item.id}`} onClick={e => scrollToSection(e, item.id)} initial={{
              opacity: 0,
              y: -20
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              delay: index * 0.1
            }} className={`text-sm font-sans tracking-wider transition-colors relative group cursor-pointer ${isScrolled ? 'text-gray-700 hover:text-gray-900' : 'text-white hover:text-gray-200'}`}>
                  {item.label}
                  <span className={`absolute -bottom-1 left-0 w-0 h-0.5 transition-all group-hover:w-full ${isScrolled ? 'bg-gray-900' : 'bg-white'}`} />
                </motion.a>)}
            </nav>

            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden p-2 z-10" aria-label="Toggle mobile menu">
              {isMobileMenuOpen ? <X size={24} className="text-gray-900" /> : <Menu size={24} className={isScrolled ? 'text-gray-900' : 'text-white'} />}
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {isMobileMenuOpen && <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} exit={{
        opacity: 0
      }} className="md:hidden fixed inset-0 bg-[#FAF7F2] z-40 pt-24">
            <motion.nav variants={mobileMenuVariants} initial="hidden" animate="visible" className="flex flex-col items-center justify-center h-full space-y-8">
              {navItems.map(item => <motion.a key={item.id} href={`#${item.id}`} onClick={e => scrollToSection(e, item.id)} variants={mobileLinkVariants} className="text-xl font-sans tracking-wider text-gray-800 hover:text-gray-900 transition-colors">
                  {item.label}
                </motion.a>)}
            </motion.nav>
          </motion.div>}
      </AnimatePresence>
    </>;
};
export default Header;